import { NextResponse } from "next/server"
import { ensureTable, getConnection, noStoreHeaders, sqlClient } from "@/lib/db"

export const dynamic = "force-dynamic"

const ROW_ID = 1

function notConfigured() {
  return NextResponse.json(
    { ok: false, stage: "env", message: "ยังไม่ได้ตั้งค่า Database URL" },
    { status: 503, headers: noStoreHeaders },
  )
}

/** GET /api/snapshot            → { record, rev }
 *  GET /api/snapshot?probe=1    → { rev }  (เบาที่สุด ใช้เช็คว่ามีของใหม่ไหม) */
export async function GET(req: Request) {
  const { url } = await getConnection()
  if (!url) return notConfigured()

  const probe = new URL(req.url).searchParams.get("probe") === "1"

  try {
    const sql = sqlClient(url)
    await ensureTable(sql)

    if (probe) {
      const rows = (await sql`select rev from app_snapshot where id = ${ROW_ID}`) as { rev: number }[]
      return NextResponse.json({ rev: rows[0]?.rev ?? 0 }, { headers: noStoreHeaders })
    }

    const rows = (await sql`select data, rev from app_snapshot where id = ${ROW_ID}`) as {
      data: Record<string, unknown> | null
      rev: number
    }[]
    const row = rows[0]
    if (!row) return NextResponse.json({ record: null, rev: 0 }, { headers: noStoreHeaders })

    const record = (row.data || {}) as Record<string, unknown>
    record.rev = row.rev
    return NextResponse.json({ record, rev: row.rev }, { headers: noStoreHeaders })
  } catch (e) {
    return NextResponse.json(
      { ok: false, stage: "db", message: e instanceof Error ? e.message : String(e) },
      { status: 500, headers: noStoreHeaders },
    )
  }
}

/** PUT /api/snapshot  body: { baseRev, record }
 *  เขียนแบบมีเงื่อนไข — ถ้ามีเครื่องอื่นเขียนแทรกจะตอบ 409 พร้อมข้อมูลล่าสุด */
export async function PUT(req: Request) {
  const { url } = await getConnection()
  if (!url) return notConfigured()

  let body: { baseRev?: number; record?: Record<string, unknown> } = {}
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ ok: false, message: "invalid json" }, { status: 400, headers: noStoreHeaders })
  }

  const baseRev = Number(body.baseRev) || 0
  const record = body.record && typeof body.record === "object" ? body.record : null
  if (!record) {
    return NextResponse.json({ ok: false, message: "missing record" }, { status: 400, headers: noStoreHeaders })
  }

  try {
    const sql = sqlClient(url)
    await ensureTable(sql)

    // แถวยังไม่มี → สร้างใหม่ (ถ้ามีเครื่องอื่นสร้างพร้อมกัน จะตกไปเช็ค 409 ด้านล่าง)
    const inserted = (await sql`
      insert into app_snapshot (id, data, rev, updated_at)
      values (${ROW_ID}, ${JSON.stringify(record)}::jsonb, ${baseRev + 1}, now())
      on conflict (id) do nothing
      returning rev, data
    `) as { rev: number; data: Record<string, unknown> }[]

    if (inserted[0]) {
      const saved = inserted[0].data || {}
      saved.rev = inserted[0].rev
      return NextResponse.json({ record: saved, rev: inserted[0].rev }, { headers: noStoreHeaders })
    }

    const updated = (await sql`
      update app_snapshot
         set data = ${JSON.stringify(record)}::jsonb,
             rev = rev + 1,
             updated_at = now()
       where id = ${ROW_ID} and rev = ${baseRev}
      returning rev, data
    `) as { rev: number; data: Record<string, unknown> }[]

    if (updated[0]) {
      const saved = updated[0].data || {}
      saved.rev = updated[0].rev
      return NextResponse.json({ record: saved, rev: updated[0].rev }, { headers: noStoreHeaders })
    }

    // rev ไม่ตรง = มีการเขียนแทรก → ส่งข้อมูลล่าสุดกลับให้ไป merge
    const current = (await sql`select data, rev from app_snapshot where id = ${ROW_ID}`) as {
      data: Record<string, unknown> | null
      rev: number
    }[]
    const latest = (current[0]?.data || {}) as Record<string, unknown>
    latest.rev = current[0]?.rev ?? 0
    return NextResponse.json(
      { ok: false, conflict: true, record: latest, rev: latest.rev },
      { status: 409, headers: noStoreHeaders },
    )
  } catch (e) {
    return NextResponse.json(
      { ok: false, stage: "db", message: e instanceof Error ? e.message : String(e) },
      { status: 500, headers: noStoreHeaders },
    )
  }
}
