import { NextResponse } from "next/server"
import { ensureTable, getConnection, noStoreHeaders, sqlClient } from "@/lib/db"

export const dynamic = "force-dynamic"

export async function GET() {
  const { url, source } = await getConnection()

  if (!url) {
    return NextResponse.json(
      {
        ok: false,
        stage: "env",
        message: "ยังไม่ได้ตั้งค่า Database URL — กรอกในหน้าตั้งค่า หรือเพิ่ม DATABASE_URL ในโปรเจกต์",
      },
      { headers: noStoreHeaders },
    )
  }

  try {
    const sql = sqlClient(url)
    await sql`select 1`
    await ensureTable(sql)

    const rows = (await sql`
      select rev,
             updated_at,
             pg_column_size(data) as size_bytes
        from app_snapshot
       where id = 1
    `) as { rev: number; updated_at: string; size_bytes: number }[]

    const row = rows[0]
    return NextResponse.json(
      {
        ok: true,
        source,
        tableExists: true,
        rev: row?.rev ?? 0,
        sizeBytes: Number(row?.size_bytes) || 0,
        updatedAt: row?.updated_at ?? null,
      },
      { headers: noStoreHeaders },
    )
  } catch (e) {
    return NextResponse.json(
      { ok: false, stage: "db", source, message: e instanceof Error ? e.message : String(e) },
      { headers: noStoreHeaders },
    )
  }
}
