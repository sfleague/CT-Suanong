import { cookies } from "next/headers"
import { NextResponse } from "next/server"
import { DB_COOKIE, ensureTable, getConnection, isValidPgUrl, maskPgUrl, noStoreHeaders, sqlClient } from "@/lib/db"

export const dynamic = "force-dynamic"

/** สถานะการตั้งค่าปัจจุบัน (ไม่เคยส่ง URL เต็มกลับไปหาเบราว์เซอร์) */
export async function GET() {
  const { url, source } = await getConnection()
  return NextResponse.json(
    {
      configured: Boolean(url),
      source,
      masked: url ? maskPgUrl(url) : null,
      editable: source !== "env",
    },
    { headers: noStoreHeaders },
  )
}

/** บันทึก Database URL ลง httpOnly cookie หลังทดสอบการเชื่อมต่อสำเร็จ */
export async function POST(req: Request) {
  let body: { url?: string } = {}
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ ok: false, message: "รูปแบบคำขอไม่ถูกต้อง" }, { status: 400 })
  }

  const url = String(body.url || "").trim()
  if (!isValidPgUrl(url)) {
    return NextResponse.json(
      { ok: false, message: "URL ไม่ถูกต้อง — ต้องเริ่มด้วย postgresql:// หรือ postgres://" },
      { status: 400 },
    )
  }

  // ทดสอบเชื่อมต่อจริงก่อนเก็บ เพื่อไม่ให้บันทึกค่าที่ใช้งานไม่ได้
  try {
    const sql = sqlClient(url)
    await sql`select 1`
    await ensureTable(sql)
  } catch (e) {
    const raw = e instanceof Error ? e.message : String(e)
    const hint = /fetch failed|ENOTFOUND|getaddrinfo/i.test(raw)
      ? "ติดต่อโฮสต์ฐานข้อมูลไม่ได้ — ตรวจสอบชื่อโฮสต์ใน URL (ต้องเป็น endpoint ของ Neon)"
      : /password|authentication/i.test(raw)
        ? "รหัสผู้ใช้หรือรหัสผ่านใน URL ไม่ถูกต้อง"
        : raw
    return NextResponse.json({ ok: false, message: "เชื่อมต่อฐานข้อมูลไม่สำเร็จ: " + hint }, { status: 400 })
  }

  const store = await cookies()
  store.set(DB_COOKIE, url, {
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  })

  return NextResponse.json({ ok: true, masked: maskPgUrl(url), source: "cookie" }, { headers: noStoreHeaders })
}

/** ลบค่าที่เก็บไว้ในคุกกี้ (กลับไปใช้ DATABASE_URL ของโปรเจกต์ถ้ามี) */
export async function DELETE() {
  const store = await cookies()
  store.delete(DB_COOKIE)
  return NextResponse.json({ ok: true }, { headers: noStoreHeaders })
}
