import { cookies } from "next/headers"
import { neon } from "@neondatabase/serverless"

/** ชื่อคุกกี้ที่เก็บ Database URL (httpOnly — JS ฝั่งเบราว์เซอร์อ่านไม่ได้) */
export const DB_COOKIE = "parcel_db_url"

export type DbSource = "cookie" | "env" | null

export function isValidPgUrl(value: string): boolean {
  if (!value) return false
  try {
    const u = new URL(value.trim())
    if (u.protocol !== "postgres:" && u.protocol !== "postgresql:") return false
    return Boolean(u.hostname)
  } catch {
    return false
  }
}

/** ซ่อนรหัสผ่าน/โฮสต์บางส่วน เพื่อแสดงบนหน้าเว็บได้อย่างปลอดภัย */
export function maskPgUrl(value: string): string {
  try {
    const u = new URL(value)
    const user = u.username ? u.username : "user"
    return `${u.protocol}//${user}:••••••@${u.hostname}${u.pathname}`
  } catch {
    return "••••••"
  }
}

export async function getConnection(): Promise<{ url: string | null; source: DbSource }> {
  const store = await cookies()
  const fromCookie = store.get(DB_COOKIE)?.value
  if (fromCookie && isValidPgUrl(fromCookie)) return { url: fromCookie, source: "cookie" }

  const fromEnv = process.env.DATABASE_URL || process.env.POSTGRES_URL || ""
  if (fromEnv && isValidPgUrl(fromEnv)) return { url: fromEnv, source: "env" }

  return { url: null, source: null }
}

export function sqlClient(url: string) {
  return neon(url)
}

export async function ensureTable(sql: ReturnType<typeof neon>) {
  await sql`
    create table if not exists app_snapshot (
      id         int primary key,
      data       jsonb       not null default '{}'::jsonb,
      rev        int         not null default 0,
      updated_at timestamptz not null default now()
    )
  `
}

export const noStoreHeaders = {
  "Cache-Control": "no-store, no-cache, max-age=0, must-revalidate",
  Pragma: "no-cache",
}
